Validation script for hw2-2

To run:

npm install
node validate.js
